// Import commands.js using ES2015 syntax:
import './commands'
import 'cypress-mochawesome-reporter/register';